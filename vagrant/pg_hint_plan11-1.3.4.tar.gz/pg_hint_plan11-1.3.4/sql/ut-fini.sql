DROP ROLE IF EXISTS super_user;
DROP ROLE IF EXISTS normal_user;
